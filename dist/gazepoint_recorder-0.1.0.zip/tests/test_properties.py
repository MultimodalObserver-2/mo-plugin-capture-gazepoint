import sys
import os
import types
import unittest
import importlib.util

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

_SRC = os.path.join(os.path.dirname(__file__), '..', 'src', 'gazepoint_recorder')


class MockPropertySelectOption:
    def __init__(self, label=None, value=None):
        self.label = label
        self.value = value


class MockProperties:
    def __init__(self):
        self._fields = {}
        self._defaults = {}

    def add_path(self, key, label=None):
        self._fields[key] = {'type': 'path', 'label': label}

    def add_int(self, key, label=None, min=None, max=None, step=None):
        self._fields[key] = {'type': 'int', 'label': label, 'min': min, 'max': max, 'step': step}

    def add_select(self, key, label=None, options=None):
        self._fields[key] = {'type': 'select', 'label': label, 'options': options or []}

    def set_default(self, key, value):
        self._defaults[key] = value

mo_stub = types.ModuleType('mo')
mo_stub.translate = lambda s: s

mo_core_stub = types.ModuleType('mo.core')
mo_core_stub.Properties = MockProperties
mo_core_stub.PropertySelectOption = MockPropertySelectOption


def load_properties():
    prev_mo = sys.modules.get('mo')
    prev_mo_core = sys.modules.get('mo.core')
    sys.modules['mo'] = mo_stub
    sys.modules['mo.core'] = mo_core_stub
    try:
        spec = importlib.util.spec_from_file_location(
            '_gz_props_mod', os.path.join(_SRC, 'properties.py'))
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        return mod
    finally:
        if prev_mo is not None:
            sys.modules['mo'] = prev_mo
        else:
            sys.modules.pop('mo', None)
        if prev_mo_core is not None:
            sys.modules['mo.core'] = prev_mo_core
        else:
            sys.modules.pop('mo.core', None)


props_mod = load_properties()

class TestPropertiesObject(unittest.TestCase):
    def test_properties_is_mock_properties_instance(self):
        self.assertIsInstance(props_mod.properties, MockProperties)

    def test_has_three_fields(self):
        self.assertEqual(len(props_mod.properties._fields), 3)

    def test_config_name_field_exists(self):
        self.assertIn('config_name', props_mod.properties._fields)

    def test_config_name_is_path_type(self):
        self.assertEqual(props_mod.properties._fields['config_name']['type'], 'path')

    def test_config_name_default(self):
        self.assertEqual(props_mod.properties._defaults['config_name'], 'Gazepoint_Config_1')

    def test_device_port_field_exists(self):
        self.assertIn('device_port', props_mod.properties._fields)

    def test_device_port_is_int_type(self):
        self.assertEqual(props_mod.properties._fields['device_port']['type'], 'int')

    def test_device_port_default(self):
        self.assertEqual(props_mod.properties._defaults['device_port'], 4242)

    def test_device_port_min(self):
        self.assertEqual(props_mod.properties._fields['device_port']['min'], 1)

    def test_device_port_max(self):
        self.assertEqual(props_mod.properties._fields['device_port']['max'], 65535)

    def test_device_port_step(self):
        self.assertEqual(props_mod.properties._fields['device_port']['step'], 1)

    def test_time_autosave_field_exists(self):
        self.assertIn('time_autosave', props_mod.properties._fields)

    def test_time_autosave_is_select_type(self):
        self.assertEqual(props_mod.properties._fields['time_autosave']['type'], 'select')

    def test_time_autosave_default(self):
        self.assertEqual(props_mod.properties._defaults['time_autosave'], 10)

    def test_time_autosave_has_four_options(self):
        opts = props_mod.properties._fields['time_autosave']['options']
        self.assertEqual(len(opts), 4)

    def test_time_autosave_option_values(self):
        opts = props_mod.properties._fields['time_autosave']['options']
        values = [o.value for o in opts]
        self.assertIn(5, values)
        self.assertIn(10, values)
        self.assertIn(15, values)
        self.assertIn(20, values)

    def test_time_autosave_option_labels(self):
        opts = props_mod.properties._fields['time_autosave']['options']
        labels = [o.label for o in opts]
        self.assertIn('5 seconds', labels)
        self.assertIn('10 seconds', labels)
        self.assertIn('15 seconds', labels)
        self.assertIn('20 seconds', labels)

    def test_options_are_select_option_instances(self):
        opts = props_mod.properties._fields['time_autosave']['options']
        for opt in opts:
            self.assertIsInstance(opt, MockPropertySelectOption)


if __name__ == '__main__':
    unittest.main()
