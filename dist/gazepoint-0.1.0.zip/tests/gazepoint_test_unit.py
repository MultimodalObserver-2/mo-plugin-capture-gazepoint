import unittest
from unittest.mock import Mock, patch, MagicMock, call
import threading
import time
import os
import sys
sys.path.append(os.path.join(os.path.dirname(__file__), '..'))
import socket
import tempfile
import shutil
from datetime import datetime

from src.gazepoint_recorder.main import GazePointRecorderPlugin
from mo.modules.capture.plugins.capture_plugin import CaptureData

class TestGazePointRecorderPlugin(unittest.TestCase):

    def setUp(self):
        self.plugin = GazePointRecorderPlugin()
        self.plugin.settings = Mock()
        self.plugin.settings.get_setting = Mock(return_value=None)
        self.test_dir = tempfile.mkdtemp()

    def tearDown(self):
        if hasattr(self.plugin, 'capture_thread') and self.plugin.capture_thread:
            self.plugin.capture_event.clear()
            self.plugin.paused_event.set()

        shutil.rmtree(self.test_dir, ignore_errors=True)

    def test_load(self):
        self.plugin.load()

        self.assertIsNotNone(self.plugin.capture_event)
        self.assertIsNotNone(self.plugin.paused_event)
        self.assertEqual(self.plugin.output_path, "")
        self.assertEqual(self.plugin.raw_output_path, "")
        self.assertIsNone(self.plugin.socket_connection)
        self.assertEqual(self.plugin.buffer, [])
        self.assertIsNone(self.plugin.last_dump_time)
        self.assertEqual(self.plugin.time_autosave, 10)
        self.assertEqual(self.plugin.device_port, 4242)
        self.assertEqual(self.plugin.screen_width, 0)
        self.assertEqual(self.plugin.screen_height, 0)
        self.assertEqual(self.plugin.workflow_status, 1)
        self.assertIsNotNone(self.plugin.pause_lock)
        self.assertEqual(self.plugin.resume_offset, 0)
        self.assertEqual(self.plugin.pause_start, 0)
        self.assertIsNone(self.plugin.capture_thread)

    def test_unload(self):
        self.plugin.load()
        self.plugin.capture_event.set()
        self.plugin.socket_connection = Mock()
        self.plugin.socket_connection.close = Mock()

        self.plugin.unload()
        self.assertFalse(self.plugin.capture_event.is_set())
        self.assertTrue(self.plugin.paused_event.is_set())
        if self.plugin.socket_connection:
            self.plugin.socket_connection.close.assert_called_once()
    
    def test_prepare(self):
        self.plugin.load()
        self.plugin.settings.get_setting.side_effect = lambda x: None
        path = os.path.join(self.test_dir, "test_path")
        file_name = "test_file"

        self.plugin.prepare(path, file_name)
        expected_output_path = os.path.join(path, f"{file_name}.txt")
        expected_raw_path = os.path.join(path, f"{file_name}.raw")

        self.assertEqual(self.plugin.output_path, expected_output_path)
        self.assertEqual(self.plugin.raw_output_path, expected_raw_path)
        self.assertEqual(self.plugin.device_port,4242)
        self.assertEqual(self.plugin.time_autosave, 10)
        self.assertTrue(os.path.exists(path))
        self.assertTrue(os.path.exists(expected_output_path))
        self.assertTrue(os.path.exists(expected_raw_path))
        self.assertTrue(self.plugin.paused_event.is_set())
        self.assertIsNotNone(self.plugin.last_dump_time)

    @patch('threading.Thread')
    def test_start(self, mock_thread):
        self.plugin.load()
        start_ts = 1000.0
        mock_get_timestamp = Mock(return_value=1001.0)
        mock_on_data = Mock()
        mock_thread_instance = Mock()
        mock_thread.return_value = mock_thread_instance

        self.plugin.start(start_ts, mock_get_timestamp, mock_on_data)
        self.assertEqual(self.plugin.recording_start_ts, start_ts)
        self.assertEqual(self.plugin.get_timestamp, mock_get_timestamp)
        self.assertEqual(self.plugin.on_data, mock_on_data)
        self.assertTrue(self.plugin.capture_event.is_set())
        self.assertTrue(self.plugin.paused_event.is_set())
        self.assertEqual(self.plugin.workflow_status, 1)
        self.assertIsNotNone(self.plugin.capture_thread)
        self.assertTrue(self.plugin.capture_thread.daemon)
        mock_thread.assert_called_once()
        mock_thread_instance.start.assert_called_once()

    def test_pause(self):
        self.plugin.load()
        self.plugin.capture_event.set()
        self.plugin.paused_event.set()
        pause_ts = 2000.0

        self.plugin.pause(pause_ts)
        self.assertFalse(self.plugin.paused_event.is_set())
        self.assertEqual(self.plugin.workflow_status, 2)
        self.assertEqual(self.plugin.pause_start, pause_ts)

    def test_resume(self):
        self.plugin.load()
        self.plugin.capture_event.set()
        self.plugin.paused_event.clear()
        self.plugin.pause_start = 2000.0
        resume_ts = 3000.0

        self.plugin.resume(resume_ts)
        self.assertTrue(self.plugin.paused_event.is_set())
        self.assertEqual(self.plugin.workflow_status, 1)
        self.assertEqual(self.plugin.resume_offset, 1000.0)

    def test_stop(self):
        self.plugin.load()
        self.plugin.capture_event.set()
        self.plugin.paused_event.clear()
        self.plugin.capture_thread = Mock()
        self.plugin.capture_thread.is_alive = Mock(return_value=True)
        self.plugin.capture_thread.join = Mock()

        self.plugin.stop(1000.0)
        self.assertFalse(self.plugin.capture_event.is_set())
        self.assertTrue(self.plugin.paused_event.is_set())
        self.assertEqual(self.plugin.workflow_status, 0)
        self.plugin.capture_thread.join.assert_called_once_with(timeout=2.0)

    def test_get_file_extension(self):
        self.plugin.load()
        self.assertEqual(self.plugin.get_file_extension(), "txt")

    def test_get_output_descriptor(self):
        self.plugin.load()
        descriptor = self.plugin.get_output_descriptor()

        self.assertIsNotNone(descriptor)
        self.assertEqual(descriptor["format"], "gaze_data")
        self.assertEqual(descriptor["version"], "1.0")
        self.assertIn("timestamp", descriptor["fields"])
        self.assertEqual(descriptor["coordinate_system"], "screen_pixels")

    @patch('socket.socket')
    def test_connect_gazepoint(self, mock_socket):
        self.plugin.load()
        self.plugin.device_port = 4242
        mock_socket_instance = Mock()
        mock_socket.return_value = mock_socket_instance

        self.plugin.connect_gazepoint()
        mock_socket.assert_called_once_with(socket.AF_INET, socket.SOCK_STREAM)
        mock_socket_instance.connect.assert_called_once_with(('127.0.0.1', 4242))
        mock_socket_instance.settimeout.assert_called_once_with(0.1)
        self.assertEqual(self.plugin.socket_connection, mock_socket_instance)

    @patch('time.sleep')
    def test_setup_gazepoint(self, mock_sleep):
        self.plugin.load()
        mock_socket = Mock()
        self.plugin.socket_connection = mock_socket

        self.plugin.setup_gazepoint()
        expected_commands = [
            '<SET ID="ENABLE_SEND_DATA" STATE="1" />',
            '<SET ID="ENABLE_SEND_POG_FIX" STATE="1" />',
            '<SET ID="ENABLE_SEND_POG_LEFT" STATE="1" />',
            '<SET ID="ENABLE_SEND_POG_RIGHT" STATE="1" />',
            '<SET ID="ENABLE_SEND_POG_BEST" STATE="1" />',
            '<SET ID="ENABLE_SEND_PUPIL_LEFT" STATE="1" />',
            '<SET ID="ENABLE_SEND_PUPIL_RIGHT" STATE="1" />',
            '<GET ID="SCREEN_SIZE" />',
        ]
        self.assertEqual(mock_socket.sendall.call_count, len(expected_commands))
        self.assertEqual(mock_sleep.call_count, len(expected_commands))

    

    def test_parse_insufficient_parts(self):
        self.plugin.load()
        data_line = '<REC CNT="0" TIME="1000" />'
        result = self.plugin.parse_gazepoint_data(data_line)
        self.assertIsNone(result)

    def test_perse_screen_size(self):
        self.plugin.load()
        data_line = '<ACK ID="SCREEN_SIZE" X="1920" Y="1080" />'
        result = self.plugin.parse_gazepoint_data(data_line)
        self.assertIsNone(result)

    def test_parse_data_invalid(self):
        self.plugin.load()
        result = self.plugin.parse_gazepoint_data("invalid_data")
        self.assertIsNone(result)

    @patch('time.time')
    def test_process_data(self, mock_time):
        self.plugin.load()
        self.plugin.screen_width = 1920
        self.plugin.screen_height = 1080
        self.plugin.last_dump_time = 1000.0
        mock_time.return_value = 1001.0

        data = {
            'fpogx': 0.5, 'fpogy': 0.6, 'fpogv': 1,
            'lpogx': 0.4, 'lpogy': 0.5, 'lpogv': 1,
            'rpogx': 0.6, 'rpogy': 0.7, 'rpogv': 1,
            'bpogx': 0.5, 'bpogy': 0.6, 'bpogv': 1,
            'lpcx': 0.4, 'lpcy': 0.5, 'lpd': 3.5, 'lpv': '1',
            'rpcx': 0.6, 'rpcy': 0.7, 'rpd': 3.6, 'rpv': '1'
        }
        timestamp = 1640995200.0
        self.plugin.process_data(data, timestamp)
        
        self.assertEqual(len(self.plugin.buffer), 1)
        buffer_line = self.plugin.buffer[0]
        self.assertIn("1640995200000", buffer_line)
        self.assertIn("2021-12-31", buffer_line)
        self.assertIn("0.50000", buffer_line)
        self.assertIn("0.60000", buffer_line)
        self.assertIn("1", buffer_line)
        self.assertIn("1920", buffer_line)
        self.assertIn("1080", buffer_line)

    @patch('time.time')
    def test_process_data_autosave(self, mock_time):
        self.plugin.load()
        self.plugin.time_autosave = 10
        self.plugin.last_dump_time = 1000.0
        mock_time.return_value = 1015.0
        data = {
            'fpogx': 0.5, 'fpogy': 0.6, 'fpogv': 1,
            'lpogx': 0.4, 'lpogy': 0.5, 'lpogv': 1,
            'rpogx': 0.6, 'rpogy': 0.7, 'rpogv': 1,
            'bpogx': 0.5, 'bpogy': 0.6, 'bpogv': 1,
            'lpcx': 0.4, 'lpcy': 0.5, 'lpd': 3.5, 'lpv': '1',
            'rpcx': 0.6, 'rpcy': 0.7, 'rpd': 3.6, 'rpv': '1'
        }

        self.plugin.dump_to_file = Mock()
        self.plugin.process_data(data, 1640995200.0)
        self.plugin.dump_to_file.assert_called_once()

    def test_dump_to_file(self):
        self.plugin.load()
        self.plugin.raw_output_path = os.path.join(self.test_dir, "test.raw")
        self.plugin.buffer = ["line1\n", "line2\n", "line3\n"]
        
        self.plugin.dump_to_file()
        self.assertEqual(len(self.plugin.buffer), 0)
        self.assertIsNotNone(self.plugin.last_dump_time)

        with open(self.plugin.raw_output_path, 'r') as f:
            content = f.read()
            self.assertIn("line1", content)
            self.assertIn("line2", content)
            self.assertIn("line3", content)

    def test_dump_to_file_empty(self):
        self.plugin.load()
        self.plugin.raw_output_path = os.path.join(self.test_dir, "test.raw")
        self.plugin.buffer = []

        self.plugin.dump_to_file()
        self.assertEqual(len(self.plugin.buffer), 0)
        self.assertIsNotNone(self.plugin.last_dump_time)

    def test_disconnect_gazepoint(self):
        self.plugin.load()
        mock_socket = Mock()
        self.plugin.socket_connection = mock_socket

        self.plugin.disconnect_gazepoint()
        mock_socket.close.assert_called_once()
        self.assertIsNone(self.plugin.socket_connection)

    def test_format_gaze_line(self):
        self.plugin.load()
        self.plugin.screen_width = 1920
        self.plugin.screen_height = 1080

        parts = [
            "1000",
            "2022-01-01 00:00:00.000",
            "0.5", "0.6", "1",
            "0.4", "0.5", "1",
            "0.6", "0.7", "1",
            "0.5", "0.6", "1",
            "0.4", "0.5", "3.5", "1",
            "0.6", "0.7", "3.6", "1",
            "1920", "1080"
        ]

        result = self.plugin.format_gaze_line(parts)
        self.assertIn("t:1000 st:7", result)
        self.assertIn("fx:true", result)
        self.assertIn("sm:960.0;648.0", result)
        self.assertIn("rw:960.0;648.0", result)
        self.assertIn("lpc:768.0;540.0", result)
        self.assertIn("rpc:1152.0;756.0", result)

    def test_format_gaze_line2(self):
        self.plugin.load()
        self.plugin.screen_width = 1920
        self.plugin.screen_height = 1080

        parts = [
            "1000",
            "2022-01-01 00:00:00.000",
            "0.5", "0.6", "0",
            "0.4", "0.5", "1",
            "0.6", "0.7", "1",
            "0.5", "0.6", "1",
            "0.4", "0.5", "3.5", "1",
            "0.6", "0.7", "3.6", "1",
            "1920", "1080"
        ]

        result = self.plugin.format_gaze_line(parts)
        self.assertIn("fx:false", result)

    def test_save(self):
        self.plugin.load()
        self.plugin.buffer = ["test_data\n"]
        self.plugin.dump_to_file = Mock()
        self.plugin.formatt_final_output = Mock()

        self.plugin.save([], end_of_data=True)
        self.plugin.dump_to_file.assert_called_once()
        self.plugin.formatt_final_output.assert_called_once()

    def test_save2(self):
        self.plugin.load()
        self.plugin.dump_to_file = Mock()
        self.plugin.formatt_final_output = Mock()
        
        self.plugin.save([], end_of_data=False)
        self.plugin.dump_to_file.assert_not_called()
        self.plugin.formatt_final_output.assert_not_called()

    def test_formatt_final_output(self):
        self.plugin.load()
        self.plugin.raw_output_path = "/path/that/does/not/exist.raw"
        self.plugin.output_path = os.path.join(self.test_dir, "output.txt")

        self.plugin.formatt_final_output()

    def test_formatt_final_output2(self):
        raw_file_path = os.path.join(self.test_dir, "test.raw")
        output_file_path = os.path.join(self.test_dir, "test.txt")

        with open(raw_file_path, 'w') as f:
            f.write("TIME_TICK|DATE|FPOGX|FPOGY|FPOGV|LPOGX|LPOGY|LPOGV|RPOGX|RPOGY|RPOGV|BPOGX|BPOGY|BPOGV|LPCX|LPCY|LPD|LPV|RPCX|RPCY|RPD|RPV|WIDTH|HEIGHT\n")
            f.write("1000|2022-01-01 00:00:00.000|0.5|0.6\n")
        
        self.plugin.load()
        self.plugin.raw_output_path = raw_file_path
        self.plugin.output_path = output_file_path

        self.plugin.formatt_final_output()
        self.assertTrue(os.path.exists(output_file_path))

    def test_formatt_final_output3(self):
        raw_file_path = os.path.join(self.test_dir, "test.raw")
        output_file_path = os.path.join(self.test_dir, "test.txt")

        with open(raw_file_path, 'w') as f:
            f.write("TIME_TICK|DATE|FPOGX|FPOGY|FPOGV|LPOGX|LPOGY|LPOGV|RPOGX|RPOGY|RPOGV|BPOGX|BPOGY|BPOGV|LPCX|LPCY|LPD|LPV|RPCX|RPCY|RPD|RPV|WIDTH|HEIGHT\n")
            f.write("1000|2022-01-01 00:00:00.000|0.5|0.6|1|0.4|0.5|1|0.6|0.7|1|0.5|0.6|1|0.4|0.5|3.5|1|0.6|0.7|3.6|1|1920|1080\n")

        self.plugin.load()
        self.plugin.raw_output_path = raw_file_path
        self.plugin.output_path = output_file_path
        self.plugin.screen_width = 1920
        self.plugin.screen_height = 1080

        self.plugin.formatt_final_output()
        self.assertTrue(os.path.exists(output_file_path))
        
        with open(output_file_path, 'r') as f:
            content = f.read()
            self.assertIn("t:1000 st:7", content)
            self.assertIn("fx:true", content)
            self.assertIn("sm:960.0;648.0", content)

if __name__ == '__main__':
    unittest.main(verbosity=2)